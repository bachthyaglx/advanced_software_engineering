class Movie:
    def __init__(self, id, name, director, release_date, language, subtitle, rate):
        self.id = id
        self.name = name
        self.director = director
        self.release_date = release_date 
        self.language = language
        self.subtitle = subtitle
        self.rate = rate
