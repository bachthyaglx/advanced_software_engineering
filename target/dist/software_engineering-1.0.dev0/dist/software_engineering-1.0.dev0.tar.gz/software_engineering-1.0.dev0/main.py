# main.py
from system import System

# Instantiate the system and run it
if __name__ == "__main__":
    System().run()