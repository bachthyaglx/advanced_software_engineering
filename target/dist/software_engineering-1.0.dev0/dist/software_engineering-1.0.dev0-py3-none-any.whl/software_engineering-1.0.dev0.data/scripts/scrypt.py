#!python
import sys
from system import System

System(sys.stdout)